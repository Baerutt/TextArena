﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextArena
{
    public class Game
    {





        
        public static string QuadChoiceException(string answerOne, string answerTwo, string answerThree, string answerFour, string prompt, string playerAnswer)
        {
            bool equality = false;
            playerAnswer = playerAnswer.ToUpper();
            if (playerAnswer == answerOne.ToUpper() || playerAnswer == answerTwo.ToUpper() || playerAnswer == answerThree.ToUpper() || playerAnswer == answerFour.ToUpper())
            {
                equality = true;
            }
            while (!equality)
            {
                Console.WriteLine("Please type an answer that equals a specific choice");
                playerAnswer = Console.ReadLine();
                playerAnswer = playerAnswer.ToUpper();
                if (playerAnswer == answerOne.ToUpper() || playerAnswer == answerTwo.ToUpper() || playerAnswer == answerThree.ToUpper() || playerAnswer == answerFour.ToUpper())
                {
                    equality = true;
                }
            }
            return playerAnswer.ToUpper();
        }
        public static string TriChoiceException(string prompt, string playerAnswer)
        {
            bool equality = false;
            playerAnswer = playerAnswer.ToUpper();
            if(playerAnswer == "1" || playerAnswer == "2" || playerAnswer == "3")
            {
                equality = true;
            }
            while(!equality)
            {
                Console.WriteLine("Please type 1, 2 or 3");
                playerAnswer = Console.ReadLine();
                playerAnswer = playerAnswer.ToUpper();
                if (playerAnswer == "1" || playerAnswer == "2" || playerAnswer == "3")
                {
                    equality = true;
                }
            }

            return playerAnswer.ToUpper();
        }
        public static string DualChoiceException(string prompt, string playerAnswer)
        {
            bool equality = false;
            playerAnswer = playerAnswer.ToUpper();

            if (playerAnswer == "1" || playerAnswer == "2")
            {
                equality = true;
            }
            while (!equality)
            {
                Console.WriteLine("Please type 1 or 2");
                playerAnswer = Console.ReadLine();
                playerAnswer = playerAnswer.ToUpper();
                if (playerAnswer == "1" || playerAnswer == "2")
                {
                    equality = true;
                }
            }

            return playerAnswer;
        }

        
    }
   
}
