﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextArena
{
    internal class Raptor : Enemy
    {
        public Raptor(string name, Weapon eWeapon, int health, int maxHealth) :
                    base(name, "Raptor", eWeapon, health, maxHealth, "Peircing")
        {

        }

        public override void EnemyAction(Player protag)
        {
            if (!offBalance)
            {
                Attack(protag);
            }
            else if (offBalanceTimer == 2)
            {
                Console.WriteLine(this.name + " is regaining it's composition");

                offBalanceTimer--;
            }
            else if (offBalanceTimer == 1)
            {
                Console.WriteLine(this.name + " Regained it's composition");

                offBalanceTimer = 2;
                offBalance = false;
            }
            else if (offBalanceTimer == 0)
            {

            }
            else
            {
                Attack(protag);
            }
        }
    }
}
