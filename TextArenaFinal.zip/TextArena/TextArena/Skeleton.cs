﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextArena
{
    internal class Skeleton : Enemy
    {
        public Skeleton(string name, Weapon eWeapon, int health, int maxHealth) :
            base(name, "Skeleton", eWeapon, health, maxHealth, "Bludgeoning")
        {

        }

        public override void EnemyAction(Player protag)
        {
            if (protag.ReturnHealth() > 0)
            {

                if (!offBalance)
                {
                    Attack(protag);
                }
                else
                {
                    Console.WriteLine(name + " Regained it's composition");
                    offBalance = false;
                }

            }
        }
    }
}
