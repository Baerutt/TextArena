﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextArena
{
    internal class Weapon
    {
        string name;
        int power;
        int accruacy;
        string damageType;

        public Weapon()
        {

        }

        public Weapon(string weapName, int force, int acc, string dmg)
        {
            name = weapName;
            power = force;  
            accruacy = acc; 
            damageType = dmg;   

        }
        public int GetPower()
        {
            return power;
        }

        public int GetAccuracy()
        {
            return accruacy;
        }

        public string GetDamageType()
        {
            return damageType;
        }
        
        public string ReturnName()
        {
            return name;
        }

    }

}
