﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextArena
{
    internal class MageKnight : Enemy
    {

        int chance;
        bool hasParried;
        int charge = 1;
        int chargeAttack = 0;
        public MageKnight(string name, Weapon eWeapon, int health, int maxHealth) : 
            base(name, "Mage Knight", eWeapon, health, maxHealth, "N/A")
        {

        }

        public override void EnemyAction(Player protag)
        {
            Random RNG = new Random();
            chance = RNG.Next(1, 5);

            if(health <= 0)
            {

            }
            else if (offBalance)
            {
                offBalance = false;
                Console.WriteLine(this.name + " Regained it's composition");

            }
            else if (chargeAttack == 1 && hasParried)
            {
                Attack(protag);
                Console.WriteLine($"{protag.GetName()} can't move!");
                Attack(protag);
                charge = 0;
                chargeAttack = 0;
                hasParried = false;
            }
            else if (chargeAttack == 1 && !hasParried)
            {
                Console.WriteLine($"The {name} waited to parry...\nBut nothing happened");
                charge = 0;
                chargeAttack = 0;
            }
            else if (chargeAttack == 2)
            {
                Console.WriteLine($"The {eWeapon.ReturnName()} glows with power!");
                SpecialAttack(protag);
                charge = 0;
                chargeAttack = 0;
            }
            else if (chance == 1)
            {

                Console.WriteLine(this.name + " is readying their attack");
                charge = 1;
                chargeAttack = 1;

            }
            else if (chance == 2)
            {
                Console.WriteLine(this.name + " is readying their attack");
                charge = 1;
                chargeAttack = 2;
            }
            else if(chance == 4)
            {
                HealUp();
            }
            else
            {
                Attack(protag);
            }
        }

        public void HealUp()
        {
            if(health == maxHealth)
            {
                Console.WriteLine($"The {name} tried to heal, but failed");
            }
            else
            {
                health = health + 20;
                if (health > maxHealth)
                {
                    health = maxHealth;

                }
                    Console.WriteLine($"The {name} healed up!");
            }

        }
        public void SpecialAttack(Player protag)
        {
            Console.WriteLine(name + " unleashes the power for their sword!!!");
            
                    protag.LoseHealth(20);
                    Console.WriteLine(protag.GetName() + " got hit by " + name + "'s Ultimate Attack and took 20 damage!");
                    Console.WriteLine("You have " + protag.ReturnHealth() + " out of 50 health left");

                    if (protag.ReturnLifeStatus())
                    {
                        Console.WriteLine(" You were defeated!");

                    }        
        }
        public void Parries()
        {
            hasParried = true;
        }

        public int ReturnAttackType()
        {
            return chargeAttack;
        }
    }

}
