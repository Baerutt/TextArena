﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextArena
{
    internal class Player
    {
        //https://learn.microsoft.com/en-us/dotnet/api/system.random?view=net-6.0
        int healUses;
        string name;
        Weapon weapon;
        int health;
        int maxHealth;
        bool isDead;
        int parryNum;
        public Player()
        {
            healUses = 2;
            isDead = false;
        }
        public Player(string pName, Weapon pWeapon, int hP, int mHP)
        {
            healUses = 2;
            name = pName;
            weapon = pWeapon;
            health = hP;
            maxHealth = mHP;
            isDead = false;

        }

        
        public void Attack(MageKnight knight)
        {
           
                parryNum = 0;
                int chance;
                int aDamage;
                Random RNG = new Random();
                Console.WriteLine(name + " is attacking " + knight.GetName());
                chance = RNG.Next(1, 101);
               
                if (knight.ReturnAttackType() == 1)
                    {
                    knight.Parries();
                    Console.WriteLine($"The {knight.GetName()} Parried {name}!!!");
                    }
                else if (knight.IsOffBalance())
                {
                    Console.WriteLine("The attack hit!");
                    aDamage = weapon.GetPower();
                    if (weapon.GetDamageType() == "Critical")
                        aDamage = aDamage * 2;
                knight.loseHealth(aDamage);
                    Console.WriteLine("The " + knight.GetName() + " was dealt " + aDamage + " damage.");
                    if (knight.IsItDead())
                    {
                        Console.WriteLine(knight.GetName() + " was defeated!");
                    }
                }
                else if (chance > weapon.GetAccuracy())
                {
                    Console.WriteLine("The attack missed!");
                }
                else
                {
                    Console.WriteLine("The attack hit!");
                    aDamage = weapon.GetPower();
                    if (weapon.GetDamageType() == "Critical")
                    aDamage = aDamage * 2;
                    knight.loseHealth(aDamage);
                    Console.WriteLine("The " + knight.GetName() + " was dealt " + aDamage + " damage.");
                    if (knight.IsItDead())
                    {
                        Console.WriteLine(knight.GetName() + " was defeated!");
                    }

                }
        }
        public void Attack(Enemy enemy)
        {
            parryNum = 0;
            int chance;
            int aDamage;
            Random RNG = new Random();
            Console.WriteLine(name + " is attacking " + enemy.GetName());
            chance = RNG.Next(1, 101);
            if(enemy.IsOffBalance())
            {
                Console.WriteLine("The attack hit!");
                aDamage = weapon.GetPower();
                if (enemy.GetWeakness() == weapon.GetDamageType())
                    aDamage = aDamage * 2;
                else if (weapon.GetDamageType() == "Critical")
                    aDamage = aDamage * 2;
                enemy.loseHealth(aDamage);
                Console.WriteLine("The " + enemy.GetName() + " was dealt " + aDamage + " damage.");
                if (enemy.IsItDead())
                {
                    Console.WriteLine(enemy.GetName() + " was defeated!");
                }
            }
            else if(chance > weapon.GetAccuracy())
            {
                Console.WriteLine("The attack missed!");
            }
            else
            {
                Console.WriteLine("The attack hit!");
                aDamage = weapon.GetPower();
                if (enemy.GetWeakness() == weapon.GetDamageType())
                    aDamage = aDamage * 2;
                else if (weapon.GetDamageType() == "Critical")
                    aDamage = aDamage * 2;
                enemy.loseHealth(aDamage);
                Console.WriteLine("The " + enemy.GetName() + " was dealt " + aDamage + " damage." );
                if(enemy.IsItDead())
                {
                    Console.WriteLine(enemy.GetName() + " was defeated!");
                }

            }


        }

        public void Defend()
        {
            parryNum = 66;

        }

        public void Heal()
        {
            health = maxHealth;
            healUses--;
        }

        public string CheckWeapon()
        {
            return weapon.ReturnName();
        }

        public void IsDead()
        {
            isDead = true;
        }
        public bool ReturnLifeStatus()
        {
            return isDead;
        }
        public void LoseHealth(int amount)
        {
            health = health - amount;

            if (health <= 0)
            {
                health = 0;
                isDead = true;
            }
        }

        public void GainHealth(int amount)
        {
            health = health + amount;
            if (health > maxHealth)
            {
                health = maxHealth;
            }
        }
        public int ReturnHealth()
        {
            return health;
        }

        public string GetName()
        {
            return name;
        }

        public int GetParry()
        {
            return parryNum;

        }

        public int GetHealNum()
        {
            return healUses;
        }
    }
}
