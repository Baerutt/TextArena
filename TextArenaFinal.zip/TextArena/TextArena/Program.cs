﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing.Drawing2D;
using System.Media;
using System.Threading;




namespace TextArena
{
    internal class Program
    {
        

        static void Main(string[] args)
        {
            //Soundplayer stuff was given to me by Emre

            //string charName = "";
            //Weapon weaponChoice;

            Game game = new Game();
            Random RNG = new Random();
            int who = 0;
            int round = 1;
            Weapon hammer = new Weapon("Hammer", 10, 76, "Bludgeoning");
            Weapon sword = new Weapon("Sword", 7, 101, "Slashing");
            Weapon swordPlus = new Weapon("Magic Sword", 9, 101, "Slashing");
            Weapon spear = new Weapon("Spear", 8, 91, "Piercing");
            Weapon luckySeven = new Weapon("Lucky 7", 14, 777, "Critical");
            Weapon wand = new Weapon("Wizard Staff", 17, 101, "Magical");
            Player me;
            Weapon bone = new Weapon("Bone", 3, 56, "None");
            Weapon club = new Weapon("Club", 5, 70, "Bludgeoning");
            Weapon claw = new Weapon("Claw", 6, 85, "Peircing");

            //Player me = new Player("Barrett", luckySeven, 50, 50);

            List<Enemy> skellyLineUp = new List<Enemy>();
            List<Enemy> ogreLineUp = new List<Enemy>();
            List<Enemy> raptorLineUp = new List<Enemy>();
            List<Enemy> FinalLineUp = new List<Enemy>();
            List<List<Enemy>> DoubleR = new List<List<Enemy>>();
            List<Enemy> upNext = new List<Enemy>();

            List<Skeleton> skellUp = new List<Skeleton>();

            Skeleton skeletonA = new Skeleton("SkellyBro A", bone, 10, 10);
            Skeleton skeletonB = new Skeleton("SkellyBro B", bone, 10, 10);
            skellyLineUp.Add(skeletonA);
            skellyLineUp.Add(skeletonB);
            skellUp.Add(skeletonA);
            skellUp.Add(skeletonB);

            Ogre OgreA = new Ogre("Ogre Bro A", club, 21, 21);
            Ogre OgreB = new Ogre("Ogre Bro B", club, 21, 21);
            ogreLineUp.Add(OgreA);
            ogreLineUp.Add(OgreB);

            Raptor RaptorA = new Raptor("Raptor A", claw, 24, 24);
            Raptor RaptorB = new Raptor("Raptor B", claw, 24, 24);
            raptorLineUp.Add(RaptorA);
            raptorLineUp.Add(RaptorB);

            Skeleton SkeletonC = new Skeleton("Skeleton Soldier", spear, 20, 20);
            Ogre OgreC = new Ogre("Ogre Soldier", sword, 21, 21);
            Raptor RaptorC = new Raptor("Raptor", claw, 24, 24);

            MageKnight mageKnight = new MageKnight("Mage Knight", swordPlus, 150, 150);


            DoubleR.Add(skellyLineUp);
            DoubleR.Add(ogreLineUp);
            DoubleR.Add(raptorLineUp);



            Console.Title = "Text Arena";

            //me.Attack(skeleton);


            GameRules();
            me = GameSetUp();



            Console.Title = "Round 1";
            who = RNG.Next(0, 3);
            Console.WriteLine(who);
            upNext = DoubleR[who];
            DoubleR.RemoveAt(who);
            ArenaRound(me, upNext, round);
            if (me.ReturnLifeStatus())
            {
                GameOver(round);
            }
            else
            {
                round = UpdateRounds(round, me);
                me = RestArea(me);
                Console.Title = "Round 2";
                who = RNG.Next(0, 2);
                Console.WriteLine(who);
                upNext = DoubleR[who];
                DoubleR.RemoveAt(who);
                ArenaRound(me, upNext, round);
                if (me.ReturnLifeStatus())
                {
                    GameOver(round);
                }
                else
                {
                    round = UpdateRounds(round, me);
                    me = RestArea(me);
                    Console.Title = "Round 3";
                    upNext = DoubleR[0];
                    DoubleR.RemoveAt(0);
                    ArenaRound(me, upNext, round);

                    if (me.ReturnLifeStatus())
                    {
                        GameOver(round);
                    }
                    else
                    {
                        round = UpdateRounds(round, me);
                        me = RestArea(me);
                        FinalLineUp.Add(SkeletonC);
                        FinalLineUp.Add(OgreC);
                        FinalLineUp.Add(RaptorC);
                        Console.Title = "Round " + round;
                        ArenaRound(me, FinalLineUp, round);

                        if (me.ReturnLifeStatus())
                        {
                            GameOver(round);
                        }
                        else if (me.CheckWeapon() == "Lucky 7")
                        {
                            round = UpdateRounds(round, me);
                            me = RestArea(me);
                            Console.Title = "Round 5";
                            ArenaRound(me, mageKnight, round);
                            if (me.ReturnLifeStatus())
                            {
                                GameOver(round);
                            }

                            else
                            {
                                Console.Clear();
                                Console.Title = "Congratulations";

                                Console.Write(@"Thank you so much for playing Text Arena!
            You cleared the final round!

            Thanks for playing and hope you hade fun!
            Congratulations on beating the secret boss!!!

            Text Arena By Barrett Ury



            press Enter to Exit");
                                Console.ReadKey();

                            }
                        }
                        else
                        {
                            Console.Clear();
                            Console.Title = "Congratulations";

                            Console.Write(@"Thank you so much for playing Text Arena!
            You cleared the final round!

            Thanks for playing and hope you hade fun!

            When choosing a weapon, type 'Lucky 7' into the selection to use Lucky 7

            The blade forged with 7 different steel from 7 different smiths,
            said to be able to cut anything and wielded by a hero named Noah

            Text Arena By Barrett Ury


            press Enter to Exit");
                            Console.ReadKey();
                        }
                    }

                }


            }


        }

        //Tells the players the rules

        public static void GameRules()
        {
            Console.WriteLine("Welcome to Text Arena! Press Enter to start!");
            Console.ReadKey();
            Console.Clear();
            Console.Write(@"Welocme to Text Arena! Welcome to the Arena where
you must defeat the other contenders to 
become the champion! Press enter to look at the rules");
            Console.ReadKey();
            Console.Clear();
            Console.Write(@"During your turn, you may take two different actions


Attacking: By attacking you have a huge chance to hit an enemy and deal damage.
The more powerful the weapon, the less accuracy it has. 


Defending: By defending, you have a high chance to block attacks from hitting you.
An enemy that makes contact with you while defending will knocked off balance. 
You have a 100% chance of hitting an off-balanced enemy. Enemies that are knocked off-balance
may also suffer additional effects, such as losing their next turn

Press Enter to continue reading the rules");
            Console.ReadKey();
            Console.Clear();
            Console.Write(@"Enemies: During the tournament, enemies will be pitted against you
by themselves or in hoards. Each enemy has their own weapons that vary in power and accuracy.
In addition, enemies have their own weaknesses. Using a weapon that is good against them will
double the damage you deal. Enemies will challenge you in hoards or by themselves as you progress in
the tournament. 

Rest Areas: During the tournament in-between rounds, you will be able to fully heal yourself
2 times. There are 4 rounds in total, so make sure to save your heals for when you 
absolutely need them

Press Enter to continue");
            Console.ReadKey();
            Console.Clear();
            Console.Write(@"That's all of the basics
Now go out there and have fun!
Press the enter button to set yourself up!");
            Console.ReadKey();
            Console.Clear();
        }


        public static Player GameSetUp()
        {
            
            string meName;
            Weapon meWeapon;
            Console.WriteLine("Hello Adventurer! Please type your name for us.\nWe know this is just a computer game, please don't freak out.");
            meName = Console.ReadLine();
            Console.Write(@"You're allowed to choose from a Sword, Hammer or Spear
Sword: The Weakest of the Three, but always accurate.
Spear: Stronger than a Sword, but less accurate.
Hammer:The Strongest of the Three, but hits the least reliably.

                Pick one to use in the arena.
                ");
            Console.WriteLine("Which one would you like to use in this arena run?\n                Sword, Spear or Hammer");
            string response = Console.ReadLine();
            string choice = Game.QuadChoiceException("Sword", "Spear", "Hammer", "Lucky 7", "Which one would you like to pick?\nSword, Spear or Hammer", response);
            if (choice.ToUpper() == "HAMMER")
            {
                meWeapon = new Weapon("Hammer", 10, 76, "Bludgeoning"); ;
            }
            else if (choice.ToUpper() == "SPEAR")
            {
                meWeapon = new Weapon("Spear", 8, 91, "Piercing");

            }
            else if (choice.ToUpper() == "LUCKY 7")
            {
                 meWeapon = new Weapon("Lucky 7", 14, 777, "Critical");

            }
            else
            {
                meWeapon = new Weapon("Sword", 7, 101, "Slashing");

            }

            
            Console.WriteLine($"Alright {meName}, take care of your trusty {meWeapon.ReturnName()} and have fun!\nPress enter to continue");
            Console.ReadKey();
            return new Player(meName, meWeapon, 50, 50);
        }






        //Code for playing out a single turn
        public static void GameTurn(Player protag, List<Enemy> beasties, int rounds)
        {
            
             Console.WriteLine(protag.GetName() + ", it is your turn.");

            if (beasties.Count == 1)
            {
                    Console.WriteLine($"{beasties[0].GetName()} approaches!");
            }
            else if (beasties.Count == 2)
            {
                    Console.WriteLine($"{beasties[0].GetName()} and {beasties[1].GetName()} approach!");
            }
            else
            {
                Console.WriteLine($"{beasties[0].GetName()}, {beasties[1].GetName()} and {beasties[2].GetName()} approach!");
            }
            for (int i = 0; i < beasties.Count; i++)
            {
                if (beasties[i].IsBloodied())
                {
                    Console.WriteLine(beasties[i].GetName() + "is getting desparate!");
                }
            }

            Console.WriteLine("What would you like to do?\n1) Attack or 2) Defend?");
            string response = Console.ReadLine();
            string choice = Game.DualChoiceException("What would you like to do?\n1) Attack or 2) Defend?", response);
            if (choice.ToUpper() == "1")
            {

                if (beasties.Count == 3)
                {
                    Console.WriteLine($"Which enemy would you like to attack\n1) {beasties[0].GetName()} 2) {beasties[1].GetName()} 3) {beasties[2].GetName()}");
                    response = Console.ReadLine();
                    choice = Game.TriChoiceException($"Which enemy would you like to attack\n1) {beasties[0].GetName()} , 2) {beasties[1].GetName()} or 3) {beasties[2].GetName()}", response);
                    if (choice == "1")
                    {
                        protag.Attack(beasties[0]);
                        if (beasties[0].IsItDead())
                        {
                            beasties.RemoveAt(0);
                        }

                    }
                    else if (choice == "2")
                    {
                        protag.Attack(beasties[1]);
                        if (beasties[1].IsItDead())
                        {
                            beasties.RemoveAt(1);
                        }

                    }
                    else
                    {
                        protag.Attack(beasties[2]);
                        if (beasties[2].IsItDead())
                        {
                            beasties.RemoveAt(2);
                        }
                    }

                }
                else if (beasties.Count == 2)
                {
                    Console.WriteLine($"Which enemy would you like to attack\n1) {beasties[0].GetName()} 2){beasties[1].GetName()}");
                    response = Console.ReadLine();
                    choice = Game.DualChoiceException($"Which enemy would you like to attack\n1){beasties[0].GetName()} or 2){beasties[1].GetName()}", response);
                    if (choice == "1")
                    {
                        protag.Attack(beasties[0]);
                        if (beasties[0].IsItDead())
                        {
                            beasties.RemoveAt(0);
                        }

                    }
                    else
                    {
                        protag.Attack(beasties[1]);
                        if (beasties[1].IsItDead())
                        {
                            beasties.RemoveAt(1);
                        }

                    }
                }
                else
                {
                    protag.Attack(beasties[0]);
                    if (beasties[0].IsItDead())
                    {
                        beasties.RemoveAt(0);
                    }
                }
            }
            else
            {
               protag.Defend();
            }

            for (int i = 0; i < beasties.Count; i++)
            {
               beasties[i].EnemyAction(protag);
               if (protag.ReturnLifeStatus())
               {
                    break;
               }
            }

        }

        public static void GameTurn(Player protag, MageKnight boss, int rounds)
        {

            Console.WriteLine(protag.GetName() + ", it is your turn.");

            
                Console.WriteLine($"{boss.GetName()} approaches!");
            
                if (boss.IsBloodied())
                {
                    Console.WriteLine(boss.GetName() + "is getting desparate!");
                }

            Console.WriteLine("What would you like to do?\n1) Attack or 2) Defend?");
            string response = Console.ReadLine();
            string choice = Game.DualChoiceException("What would you like to do?\n1) Attack or 2) Defend?", response);
            if (choice == "1")
            {
              protag.Attack(boss);
            }
            else
            {
                protag.Defend();
            }

            //http://programmingisfun.com/console-application-color/
            Console.ForegroundColor = ConsoleColor.Blue;
                Console.BackgroundColor = ConsoleColor.White;
                boss.EnemyAction(protag);
                Console.ResetColor();
        }

        public static void ArenaRound(Player protag, List<Enemy> squad, int rounds)
        {
       
            while (squad.Count > 0 || squad.Count == null)
            {

                if (protag.ReturnLifeStatus())
                {
                    break;
                }
                else
                {
                    //Loops battle until it is lost
                    Console.Clear();
                    GameTurn(protag, squad, rounds);
                    Console.WriteLine("Press Enter to continue to the next turn");
                    Console.ReadKey();
                }
                
            }
        }
        public static void ArenaRound(Player protag, MageKnight boss, int rounds)
        {
            
            while (!boss.IsItDead())
            {

                if (protag.ReturnLifeStatus())
                {
                    break;
                }
                else
                {
                    //Loops battle until it is lost
                    Console.Clear();
                    GameTurn(protag, boss, rounds);
                    Console.WriteLine("Press Enter to continue to the next turn");
                    Console.ReadKey();
                }
            }
        }

        public static int UpdateRounds(int roundsWon, Player protag)
        {
            Console.WriteLine("Congratulations for making it past round " + roundsWon);
            roundsWon++;

            if (roundsWon == 5)
            {
                Console.WriteLine("The final round approaches. The ultimate foe will appear");
            }
            else if(roundsWon == 4 && protag.CheckWeapon() != "Lucky 7")
            {
                Console.WriteLine("The final round approaches.");
            }
            else
            {
                Console.WriteLine("Round " + roundsWon + " is next.");

            }
            return roundsWon;
        }

        public static void GameOver(int roundsWon)
        {
            Console.Title = "Game Over";

            Console.WriteLine("You made it to round " + roundsWon + ".\nBetter Luck next time\n\nPress Enter to continue");
            Console.ReadKey();
        }

        public static Player RestArea(Player recipient)
        {
            Console.Title = "Rest Area";
            Console.WriteLine("Welcome to the Rest Area");
            Thread.Sleep(2000);
            //https://learn.microsoft.com/en-us/dotnet/api/system.threading.thread.sleep?view=net-6.0

            Console.WriteLine("You currently have " + recipient.ReturnHealth() + " health left");
            if (recipient.GetHealNum() > 0)
            {
                Console.WriteLine("Would you like to use one of your " + recipient.GetHealNum() + " full heals remaining to fully heal yourself?\n1) Yes or 2) No?");
                string doHeal = Console.ReadLine();
                Game.DualChoiceException("Would you like to use one of your " + recipient.GetHealNum() + " full heals remaining to fully heal yourself?\n1) Yes or 2) No?", doHeal);
                if(doHeal == "1" )
                {
                    recipient.Heal();
                    Console.WriteLine("You're all healed up!");


                }
                else
                {
                    Console.WriteLine("You decided not to heal");
                }
                Console.WriteLine("You have " + recipient.GetHealNum() + " heals remaining");

            }
            else
            {
                Console.WriteLine("You have no more Full Heals left");
            }

            Console.WriteLine("Stay safe out there and have fun!\nPress enter to continue");
            Console.ReadKey();
             return recipient;
        }
    }
}
