﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextArena
{
    abstract class Enemy
    {
        protected string name;
        protected string species;
        protected Weapon eWeapon;
        protected int health;
        protected int maxHealth;
        protected string weakness;
        protected bool isDead;
        protected bool offBalance;
        protected bool bloodied;
        protected int offBalanceTimer = 2;

        public Enemy()
        {
            isDead = false;
            offBalance = false;
            bloodied = false;
            offBalanceTimer = 2;
        }
        public Enemy(string name, string species, Weapon eWeapon, int health, int maxHealth, string weakness)
        {
            this.name = name;
            this.species = species;
            this.eWeapon = eWeapon;
            this.health = health;
            this.maxHealth = maxHealth;
            this.weakness = weakness;
            isDead = false;
            offBalance = false;
            bloodied = false;
            offBalanceTimer = 2;


        }
        public abstract void EnemyAction(Player protag);
            

        public void Attack(Player protag)
        {
            int chance;
            Random RNG = new Random();
            chance = RNG.Next(1, 100);
            Console.WriteLine(name + " Attacks!!!");
            if (chance > eWeapon.GetAccuracy())
            {
                Console.WriteLine(name + " Missed " + protag.GetName());
            }
            else
            {
                chance = RNG.Next(1, 100);
                if(chance <= protag.GetParry())
                {
                    Console.WriteLine(protag.GetName() + " parried the " + eWeapon.ReturnName());
                    Console.WriteLine(name + " is off balance!");
                    offBalance = true;
                }
                else
                {
                    protag.LoseHealth(eWeapon.GetPower());
                    Console.WriteLine(protag.GetName() + " got hit by " + name + " and took " + eWeapon.GetPower() + " damage!");
                    Console.WriteLine("You have " + protag.ReturnHealth() + " out of 50 health left");

                    if (protag.ReturnLifeStatus())
                    {
                        Console.WriteLine(" You were defeated!");

                    }

                }
            }
        }

        public void loseHealth(int amount)
        {
            health = health - amount;
           
            if(health <= 0)
            {
                health = 0;
               
                isDead = true;
            }
            else if(health < maxHealth / 2)
            {
                bloodied = true;
            }
        }

        public void gainHealth(int amount)
        {
            health = health + amount;
            if(health > maxHealth)
            {
                health = maxHealth;
            }
        }

        public string GetName()
        {
            return name;
        }

        public string GetWeakness()
        {
            return weakness;
        }

        public bool IsItDead()
        {
            if (health <= 0)
                isDead = true;
            return isDead;
        }

        public bool IsOffBalance()
        {
            return offBalance;
        }

        public bool IsBloodied()
        {
            if (health < health / 3)
                bloodied = true;
            else
                bloodied = false;
            return bloodied;
        }

        public int GetHealth()
        {
            return health;
        }

        public string GetSpecies()
        {
            return species;
        }

    }

  
}
